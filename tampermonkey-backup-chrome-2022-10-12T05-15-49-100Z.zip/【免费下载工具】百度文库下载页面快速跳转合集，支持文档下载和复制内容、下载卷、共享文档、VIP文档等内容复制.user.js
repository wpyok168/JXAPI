// ==UserScript==
// @name         【免费下载工具】百度文库下载页面快速跳转合集，支持文档下载和复制内容、下载卷、共享文档、VIP文档等内容复制
// @namespace    http://m6z.cn/64QY99
// @version      1.0.13.1
// @description  This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @author       yuanshanxia
// @match        http://wenku.baidu.com/*
// @match        https://wenku.baidu.com/*
// @supportURL   http://verymatch.xyz/wk.php
// @grant        none
// ==/UserScript==
