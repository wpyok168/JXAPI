// ==UserScript==
// @name         视频广告自动跳过
// @namespace    https://greasyfork.org/zh-CN/users/430543-wulududu
// @version      1.2
// @description:zh-CN  目前已支持爱奇艺、优酷、腾讯视频
// @description:en  auto skip video ads!
// @author       wulududu
// @match        *://*.iqiyi.com/*
// @match        *://*.youku.com/*
// @match        *://v.qq.com/*
// @grant        none
// @description auto skip video ads!
// ==/UserScript==

(function() {
    let Skipper = function() {
        this.youku = function() {
            [...document.querySelectorAll('.h5-ext-layer video')].map((m) => {
                m.playbackRate = 16
                m._currentTime = 1
                m._normalEndDate -= 1000 * 15
            })
        }
        this.qq = function() {
            [...document.querySelectorAll('[data-role = "adplayer-video-container"] video')].map((m) => {
                m.currentTime += 100
            })
        }
        this.iqiyi = function() {
            [...document.querySelectorAll('.iqp-player video')].map((m, index) => {
                if(m.duration <= 120) {
                    m.currentTime += 100
                }
            })
        }
        this.getType = function() {
            const type_regexp = /\S+\.(?<type>\S+)\.+\S/
            return type_regexp.exec(location.host).groups.type

        }
        this.run = function(){
            let type = this.getType()
            setInterval(() => {
                this[type].apply(this)
            },500)
        }
    }

    let skipper = new Skipper()
    skipper.run()
})();