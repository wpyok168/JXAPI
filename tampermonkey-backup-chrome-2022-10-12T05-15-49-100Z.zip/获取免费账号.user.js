// ==UserScript==
// @name         获取免费账号
// @namespace    https://free-ss.site/
// @version      0.1
// @description  try to take over the world!
// @author       福建-兮
// @match        *://free-ss.site/
// @grant        none
// ==/UserScript==
(function() {
    'use strict';
    getSS();
    var ssArray = new Array();
    function getSS() {
        var interval1 = setInterval(function() {
            var tbss = document.getElementById("tbss");
            var tbbody = tbss.getElementsByTagName("tbody");
            for (var i = 0; i < tbbody.length; i++) {
                var trr = tbbody[i].getElementsByTagName("tr");
                clearInterval(interval1);
                for (var j = 0; j < trr.length; j++) {
                    var tdd = trr[j].getElementsByTagName("td");
                    for (var k = 0; k < tdd.length; k++) {
                        //alert(tdd[k].innerHTML);
                        ssArray[j] = tdd[4].innerHTML + ':' + tdd[3].innerHTML + '@' + tdd[1].innerHTML + ':' + tdd[2].innerHTML;
                        //alert(ssArray[j]);
                    }
                }
                //alert(ssArray.length);
                sstobase64();
            }
        },
        800);
    }

    var ss = "";
    function sstobase64() {
        for (var x = 0; x < ssArray.length; x++) {
            //alert(ssArray[x]);
            ss += 'ss://' + encode(ssArray[x]) + '\n';
        }
        //alert(ss);
        copyText(ss);
    }

    // 字符串转base64
    function encode(str) {
        // 对字符串进行编码
        var encode = encodeURI(str);
        // 对编码的字符串转化base64
        var base64 = btoa(encode);
        return base64;
    }
    // base64转字符串
    function decode(base64) {
        // 对base64转编码
        var decode = atob(base64);
        // 编码转字符串
        var str = decodeURI(decode);
        return str;
    }
    //复制
    function copyText(cptext) {
        //var obj = document.getElementById("su");
        var copytext = cptext.toString();
        //alert(copytext.toString());
        navigator.clipboard.writeText(copytext.toString()).then(function() {
            /* clipboard successfully set */
            alert("ss账号信息已复制到剪切板！\n\n" + copytext);
        },
        function() {
            /* clipboard write failed */
            alert("复制失败！");
        });
    }
    // Your code here...
})();