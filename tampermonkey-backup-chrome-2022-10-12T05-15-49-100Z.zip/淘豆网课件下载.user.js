// ==UserScript==
// @name         淘豆网课件下载
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match       https://www.taodocs.com/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==
// https://www.taodocs.com/p-281180262.html

(function() {
    'use strict';
//var t =setInterval(function(){var jx =document.querySelector('#html-reader-go-more > div > span'); if(jx!=null) {jx.click();} else{clearInterval(t);} },800);
//var t1 =setInterval(function(){var jx =document.querySelector('#html-reader-go-more > p.banner-more-title'); if(jx!=null) {imgf();clearInterval(t1);}},800);
var t = setInterval(function () {
    var jx = document.querySelector('#html-reader-go-more > div > span');
    if (jx != null) {
        jx.click();
    } else {
        clearInterval(t);
    }
}, 2000);
var t1 = setInterval(function () {
    var jx = document.querySelector('#html-reader-go-more > p.banner-more-title');
    if (jx != null && jx.innerText.indexOf("阅读已结束")!=-1) {
        clearInterval(t1);
        imgf();

    }
}, 1500);

function imgf() {
    //alert("阅读结束");
    var img = document.body.getElementsByTagName('img');
    var k = 0;
    for (var i = 0; i < img.length; i++) {
        //alert(img[i].src);
        if (img[i].src.indexOf('//view.taodocs.com/img/') != -1) {
            //dwimg = setInterval(downLoad(img[i].src),2000);
        }
        if(i==img.length){clearInterval(dwimg);}
    }
}
var dwimg;
function downLoad(imgurl) {
    alert(imgurl);
    var x = new XMLHttpRequest();
    x.open("GET", imgurl, true);
    x.responseType = 'blob';
    x.onload = function (e) {
        var url = window.URL.createObjectURL(x.response)
        var a = document.createElement('a');
        a.href = url
        a.download = ''
        a.click()
    }
    x.send();
}

    // Your code here...
})();