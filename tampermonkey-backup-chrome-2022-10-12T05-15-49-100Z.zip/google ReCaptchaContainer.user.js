// ==UserScript==
// @name         google ReCaptchaContainer
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        *://www.public.ctc.edu/ApplicantWebClient/Applicant/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
geti0116();
function geti0116() {
    var interval1 = setInterval(function() {
        var i0116 = document.querySelector("recaptcha-checkbox-border");
        if (i0116 != null) {
            clearInterval(interval1);
            i0116.click();
        }
    },
    800);
};
    // Your code here...
})();