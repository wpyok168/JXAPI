// ==UserScript==
// @name         提取微视去水印视频
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://h5.weishi.qq.com/*
// @match        https://isee.weishi.qq.com/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    /**   复杂代码，学习用
var myVar = setInterval(myTimer, 1000);
    function myTimer()
    {
		var divParas = document.getElementsByTagName("div");
		for (var i = 0; i < divParas.length; i++) {
			if(divParas[i].innerHTML.indexOf("vpjs-videoContainer-")!=-1)
			{
				clearInterval(myVar);
				var videodiv = divParas[i].getElementsByTagName("div")
				for(var j=0;j<videodiv.length; j++)
				{
                    var divid=videodiv[j].getAttribute("id");
                    if(divid!=null){
                        if(divid.indexOf("vpjs-videoContainer-") != -1)
                        {
                            //alert(videodiv[j].innerHTML);
                            var video = videodiv[j].getElementsByTagName("video");
                            if(video!=null){alert(video.item(0).getAttribute("src"));}
                            break;
                        }
                    }
				}
			break;
			}
		}
    }
    **/
var myVar = setInterval(myTimer, 1000);
    function myTimer()
    {
        var divs = document.getElementsByTagName("div");
        for(var i=0;i<divs.length;i++)
            {
               if(divs[i].innerHTML.indexOf("mp4")!=-1)
               {
                   var video = divs[i].getElementsByTagName("video");
                   if(video.length>1)
                   {
                       clearInterval(myVar);
                       for(var j=0;j<divs.length;j++)
                       {
                           if(divs[j].getAttribute("class")!=null)
                           {
                               if(divs[j].getAttribute("class")=="swiper-slide swiper-slide-active")
                               {
                                   video = divs[j].getElementsByTagName("video");
                                   if(video!=null)
                                   {
                                       //alert("启动"+video.length);
                                       //alert(video.item(0).getAttribute("src"));
                                       cp(video.item(0).getAttribute("src"));
                                       break;
                                   }
                               }
                           }
                       }

                   }else if(video.length==1)
                   {
                       clearInterval(myVar);
                       //alert("启动"+video.length);
                       //alert(video.item(0).getAttribute("src"));
                       cp(video.item(0).getAttribute("src"));

                   }
                   break;
               }
            }
    }
        function cp(cpstr){
            //alert(cpstr);
       navigator.clipboard.writeText(cpstr.toString()).then(function() {
                        /* clipboard successfully set */
                        alert("去水印视频地址已复制到剪贴板！\n"+cpstr);
                    },
                      function() {
                        /* clipboard write failed */
                        var txt ="如你使用的是Firfox浏览器，请打开about:config并将dom.events.testing.asyncClipboard设为true后重试";
                        alert("复制失败！\n\n" + txt);
                    });
    }
    // Your code here...
})();