// ==UserScript==
// @name         种豆得豆
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        *://bean.m.jd.com/plantBean/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    setInterval(()=>{
        document.querySelector("#hello > div > div > div > div > div > div > div.react-view.gameView > div.react-view.mainView > div:nth-child(6) > div > div > div > div").click();
        document.querySelector("#hello > div > div > div > div > div > div > div.react-view.gameView > div.react-view.mainView > div:nth-child(6) > div > div > div > div > div").click();
        document.querySelector("#hello > div > div > div > div > div > div > div.react-view.gameView > div.react-view.mainView > div:nth-child(6) > div > div > div > div > div > div").click();
        document.querySelector("#hello > div > div > div > div > div > div > div.react-view.gameView > div.react-view.mainView > div:nth-child(6) > div > div > div > div > div > span").click();
    },3000);

    // Your code here...
})();