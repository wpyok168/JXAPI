// ==UserScript==
// @name         patch for 课件站
// @namespace    http://www.c-xyyx.cn

// @version      0.1
// @description  patch for kjzhan
// @author       逍遥一仙
// @match        http://www.kjzhan.com/*/*/*

// @grant        none
// ==/UserScript==

var num=document.getElementsByTagName('a')
for (var i=0;i<num.length;i++)
{if(num[i].href.indexOf("download")!=-1){
var aa=true;
var ju_url=num[i].href;
num[i].target='';
num[i].href='javascript:getfile();';
num[i].onclick='getfile()';}}
window.getfile=function(){
xmlhttp=null;
aa=true;
xmlhttp=new XMLHttpRequest();
xmlhttp.open("GET",ju_url,true);
xmlhttp.onreadystatechange=handleStateChange;
xmlhttp.send();};
function handleStateChange(){
if(aa==true){var bb=xmlhttp.responseText.match('download.php?(.*?)"')[0]; window.open("http://www.kjzhan.com/plus/"+bb.substring(0,bb.length-1));aa=false;}}
