// ==UserScript==
// @name         复制Edu账号
// @namespace    https://my.madisoncollege.edu/app/profile/search
// @version      0.1
// @description  try to take over the world!
// @author       福建-兮
// @match        https://my.madisoncollege.edu/app/profile/accountactivate
// @grant        none
// ==/UserScript==
(function() {
    'use strict';
    var acount = "";
    getcount();
    //获取账号
    function getcount() {
        //alert("a");
        var btn = document.getElementsByTagName("div");

        for (var j = 0; j < btn.length; j++) {
            if (btn[j].getAttribute("class") == "section-content clearfix") {
                //alert("b");
                //btn[j].focus();
                //btn[j].click();
                //btn[j].setAttribute("title", "Male");
                //var span = btn[j].getElementsByTagName("div");
                //alert("b"+span.innerHTML);
                getac(btn[j]);
            }
        }
    }

    function getac(btn) {
        var interval = setInterval(function() {
            var span = btn.getElementsByTagName("div");
            if (btn.innerHTML.indexOf("Username") != -1) {
                clearInterval(interval);
            }
            if (btn.innerHTML.indexOf("Student ID Number") != -1) {
                clearInterval(interval);
            }
            for (var i = 0; i < span.length; i++) {
                if (span[i].innerHTML == "Student ID Number") {
                    //
                    var span2 = btn.getElementsByTagName("div");
                    for (var k = 0; k < span2.length; k++) {
                        if (span2[k].getAttribute("class") == "pull-right") {
                            //span1[K].innerHTML = "Male";
                            //alert(span1[K].innerHTML);
                            var xuehao1 = span2[k].getElementsByTagName("div");
                            //alert(xuehao[0].innerHTML);
                            acount = "学号：" + xuehao1[0].innerHTML + '\n';
                            //alert(acount);
                        }
                    }
                    //
                }
                if (span[i].innerHTML == "Username") {
                    //
                    var span3 = btn.getElementsByTagName("div");
                    for (var c = 0; c < span3.length; c++) {
                        if (span3[c].getAttribute("class") == "pull-right") {
                            //span1[K].innerHTML = "Male";
                            //alert(span1[K].innerHTML);
                            xuehao1 = span3[c].getElementsByTagName("div");
                            //alert(xuehao[0].innerHTML);
                            acount = acount + "账号：" + xuehao1[0].innerHTML + "@madisoncollege.edu\n密码：Edu457667234*";
                            //alert(acount);
                            copyText(acount);
                        }
                    }
                    //
                }
                //========
            }

        },
        800);
    }

    //复制
    function copyText(cptext) {
        //var obj = document.getElementById("su");
        var copytext = cptext.toString();
        //alert(copytext.toString());
        navigator.clipboard.writeText(copytext.toString()).then(function() {
            /* clipboard successfully set */
            alert("EDU注册信息已复制到剪切板！\n\n"+copytext);
        },
        function() {
            /* clipboard write failed */
            alert("复制失败！");
        });
    }

})();