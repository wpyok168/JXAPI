// ==UserScript==
// @name         连续点击
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
setInterval(function(){document.getElementById("slotbar").click();},30);
setInterval(function (){window.location.reload();},800);
    // Your code here...
})();