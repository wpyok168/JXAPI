// ==UserScript==
// @name         vn-zoom.org辅助点击
// @namespace    https://vn-zoom.org/
// @version      0.1
// @description  try to take over the world!
// @author       福建-兮
// @match        *://vn-zoom.org/threads/share-key-windows-office-everyone-by-ldssk.7416/*
// @grant        none
// ==/UserScript==
// ==UserScript==
(function() {
    'use strict';
    //alert("b");
    var btn = document.getElementsByTagName("span");
    for (var m = 0; m < btn.length; m++) {
        if (btn[m].innerHTML.indexOf("Nội dung Ẩn") != -1) {
            //setTimeout(1000);
            btn[m].click();
        }
    }

    var dz = prompt("是否点赞：", "Y");
    if (dz == "Y") {
        var div = document.getElementsByTagName("div");
        for (var i = 0; i < div.length; i++) {
            if (div[i].getAttribute("class") == "message-main js-quickEditTarget" || div[i].getAttribute("class") == "message-content js-messageContent") {
                var div1 = div[i].getElementsByTagName("div");
                for (var j = 0; j < div1.length; j++) {
                    if (div1[j].getAttribute("class") == "bbCodeBlock-title") {
                        //alert(div1[j].innerHTML);
                        if (div1[j].innerHTML.indexOf("F5 nếu chưa thấy nội dung") != -1) {
                            var footer = div[i].getElementsByTagName("div");
                            for (var v = 0; v < footer.length; v++) {
                                if (footer[v].getAttribute("class") == "actionBar-set actionBar-set--external") {
                                    //alert(footer[v].innerHTML);
                                    var link = footer[v].getElementsByTagName("a");
                                    for (var p = 0; p < link.length; p++) {
                                        //alert(link[p].innerHTML);
                                        if (link[p].getAttribute("class").indexOf("reaction--imageHidden") != -1) {
                                            var bdi = link[p].getElementsByTagName("bdi");
                                            //alert(bdi.innerHTML);
                                            for (var n = 0; n < bdi.length; n++) {
                                                if (bdi[n].innerHTML == "Like") {
                                                    //setTimeout(1000);
                                                    bdi[n].click();
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            break;
                        }
                    }
                }
            }
        }
    }
    //
    var ref = prompt("是否20s后自动刷新页面：", "Y");
    if (ref == "Y") {
        setTimeout(function() {
            location.reload();
        },
        20000);
    }
    //location.reload();
    // Your code here...
})();