// ==UserScript==
// @name         笔趣阁类小说网站阅读页精简
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  精简笔趣阁一类模板小说网站的阅读页面
// @author       miko
// @include      /.*www\.xbiquge\.la\/\d+\/\d+\/\d+\.html/
// @include      /.*www\.xsbiquge\.com\/\d+_\d+\/\d+\.html/
// @include      *://www.ciymao.com/chapter/*/*.html
// @include      /.*www.biquge.info\/\d+_\d+\/\d+\.html/
// @include      /.*www\.bqg44\.net\/book\/\d+\/\d+\.html/
// @include      /.*www\.shubao2s\.net\/\d+_\d+\/\d+\.html/

// @require      http://libs.baidu.com/jquery/2.1.4/jquery.min.js

// @homepageURL  https://greasyfork.org/zh-CN/scripts/396935-笔趣阁类小说网站阅读页精简

// @note         V1.0--重写95%代码，解决原网页中顽固css；配色做了修改，下个版本会预计加入自定义配色；
// @note         V0.5.1--对新增匹配网站的翻页按钮及其字体颜色做了适配。（就是加了一个class）
// @note         V0.5--新增匹配四个网址，都是自己翻到啥小说网站，一看没美化，就现加的。
// @note         V0.4--删除正文底部文字广告
// @note         V0.4--修改翻页按钮字体颜色
// @note         V0.4--修改网页在宽度990px以下出现横向滚动条的bug
// @note         V0.3--新增匹配一个网址，新增清除网页js加入的广告
// @note         V0.2--更改了滚动条样式和文本选中颜色
// @grant        none
// @grant        GM_getValue
// @grant        GM_setValue
// ==/UserScript==

(function() {
    'use strict';

    /*
    *
    *    前期准备工作
    *
    */
    //取出仅需要的元素
    var h1 = $('h1')[0];
    var content = $('#content');
    var bottem;
    var bottems=$('[class^=bottem]');
    if(bottems.length==0){
        bottem = $('.read_nav')[0];
    }else{
        bottem=bottems[0];
    }
    //清除正文中的广告
    $("#content > p").remove();

    $("[src*='baidu.com']").remove();

    //清空body
    document.body.innerHTML="";

    //将提取出来的内容重新放入body

    //如果翻页超链接中有广告，则清除广告
    var a = $(bottem).children();
    if(a.length==5){
        a[0].remove();
        a[4].remove();
    }
console.log($("[onclick]"));

    //清除网页所有样式
    $('style').remove();
    $('link').remove();
    $(bottem).addClass('layui-elem-field')
    $("body").append(h1,content,bottem)
$("[onclick]").remove();

    /*
    *
    *   样式设置
    *
    **/

    /***网页整体***/
    $('*').css('margin','0 auto')
    $("body").css("background-color","#fdeff2");
    $("body").css("width","80%");
    $("body").css("max-width","1500px");

    /***标题样式***/
    $("h1").css("color","#43676b");
    $("h1").css("margin-bottom","30px");

    /***正文主体***/
    $('#content').css('color','#333631');
    //$('#content').css('margin','auto')

    /***翻页***/
    $('a').css("color","#43676b")
    $('a').css('font-size',14);
    $('a').css('text-decoration','none');

    //$('a').css('padding','10px');
    $(bottem).css('width',"80%");
    $(bottem).css('max-width',"800px");
    $(bottem).css('display',"flex");

    //$(bottem).css('margin','auto')





})();