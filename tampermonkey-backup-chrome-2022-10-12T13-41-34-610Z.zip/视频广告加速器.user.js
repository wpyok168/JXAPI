// ==UserScript==
// @name         视频广告加速器
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       fujian-xi
// @match        *://*.iqiyi.com/*
// @match        *://*.youku.com/*
// @match        *://v.qq.com/*
// @match        *://www.mgtv.com/b/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
var txgg = setInterval(function () {
    let qqvideogg = document.querySelectorAll('.txp_none video');
    if (qqvideogg.length) {
        for (let i = 0; i < qqvideogg.length; i++) {
            qqvideogg[i].setAttribute('src', undefined);
            qqvideogg[i].currentTime = 1000
        }
    }
}, 123);

var youkugg = setInterval(function () {
    var videoada = document.querySelectorAll(".h5-ext-layer div");
    if (videoada && videoada.length > 0) {
        Array.from(videoada).forEach(i => i.remove());
        var videoadb = document.getElementsByClassName("control-play-icon");
        if (videoadb && videoadb.length > 0) {
            videoadb[0].click();
        }
        clearInterval(youkugg);
    } else {}
}, 100);

function iqygg(){
function videoadobj() {
   var jxbvideoadb = setInterval(function () {
      var videoada = document.querySelectorAll(".skippable-after");
        if (videoada && videoada.length > 0) {
            videoada[0].click();
            var videoadc = document.querySelectorAll(".cd-time");
            if (videoadc && videoadc.length > 0 && parseInt(videoadc[0].innerText) > 1) {
                videoadc[0].innerText = 1;
            }
            clearInterval(jxbvideoadb);
        } else {}
    }, 1000);
};
videoadobj();
var jxbvideoada = setInterval(function () {
    var videoada = document.querySelectorAll(".cd-time");
    if (videoada && videoada.length > 0 && parseInt(videoada[0].innerText) > 1) {
        videoadobj();
    } else {}
}, 1000);
};
function manguo(){
    setInterval(function(){
        //.as_video-modal_btn.as_video-modal_btn--circle.as_video-modal_timer
        var mggg=document.querySelector(".as_video-modal_timer");
        if(mggg!=null){
            document.querySelector("video").currentTime+=1000;
            document.querySelector("video").playbackRate=16;
            //document.querySelector("#mgtv-player-wrap > container > mango-plugin-ad").remove();
            document.querySelector(".as_video-modal_btn.as_video-modal_btn--circle.as_video-modal_timer").innerHTML=0;
        }
    },500);
};

function run() {
    manguo();
    iqygg();
    txgg();
    youkugg();
}
run();
    // Your code here...
})();