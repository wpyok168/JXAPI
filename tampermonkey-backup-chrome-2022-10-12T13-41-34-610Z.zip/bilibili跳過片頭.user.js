// ==UserScript==
// @name   bilibili跳過片頭
// @name:zh-CN   bilibili跳过片头
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  等待片頭撥放點J跳過90秒，時間可到控制台更新跳過的長度，預設90S
// @description:zh-CN  等待片头拨放点J跳过90秒，时间可到控制台更新跳过的长度，预设90S
// @author       Evil墮落
// @include      *://www.bilibili.com/bangumi/play/ep*
// @include      *://www.bilibili.com/bangumi/play/ss*
// @include      *://m.bilibili.com/bangumi/play/ep*
// @include      *://m.bilibili.com/bangumi/play/ss*
// ==/UserScript==

var keyCode = 74; //啟動鍵J
var OPTime = 90; //跳過長度

document.onkeydown=function(event){
		if(event.which==keyCode){
			var video = $('.bilibili-player-video video')[0];
			if(video.currentTime>0){
				video.currentTime += (OPTime);
			}else{
				video.currentTime += OPTime;
				video.play();
			}
		}
    }