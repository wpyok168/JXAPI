// ==UserScript==
// @name         微视登录去多余页面元素
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://h5.weishi.qq.com/weishi/account/login?r_url=http%3A%2F%2Fmedia.weishi.qq.com%2F
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
var divParas = document.getElementsByTagName("div");
for (var i = 0; i < divParas.length; i++) {
    if(divParas[i].getAttribute("class") == "login-dialog" || divParas[i].getAttribute("class") == "tab active" || divParas[i].getAttribute("class") == "tabs" || divParas[i].getAttribute("class") == "tab" )
	{

	}
	else if(divParas[i].getAttribute("class") == "panel" || divParas[i].getAttribute("class") == "panel-wrapper"|| divParas[i].getAttribute("class") == "qq active")
	{

	}
	else if(divParas[i].getAttribute("class") == "content-warpper" || divParas[i].getAttribute("class") == "body-wrapper" || divParas[i].getAttribute("class") == "page-login")
	{

	}
	else
	{
		divParas[i].setAttribute("style", "display:none");
	}
}
    // Your code here...
})();