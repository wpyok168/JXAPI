// ==UserScript==
// @name         my.madisoncollege.edu注册
// @namespace    https://my.madisoncollege.edu/app/profile/search
// @version      0.1
// @description  try to take over the world!
// @author       福建-兮
// @match        *://my.madisoncollege.edu/*
// @match        *://my.madisoncollege.edu/app/profile/*
// @grant        none
// EDU邮箱：你的账号@madisoncollege.edu；密码：Edu457667234*
//https://signup.azure.com/studentverification?offerType=3
// ==/UserScript==
(function() {
    'use strict';
    if (document.getElementById('password') != null) {
        //document.getElementById('password').setAttribute("title", "Male")
        //document.getElementById('password').getAttribute("for") == "password"
        //document.getElementById('password').focus();
        document.getElementById('password').value = "Edu457667234*";
        document.getElementById('password_confirm').value = "Edu457667234*";
        document.getElementById('recover_answer').value = "Edu";
        document.getElementById('recover_question').value = "2";
        document.getElementById('agree').click();
        document.getElementById('submit').click();
    }
    var pagetitle = document.getElementsByTagName("h1");
    for (var j = 0; j < pagetitle.length; j++) {
        if (pagetitle[j].innerHTML == "Search for Current Account") {
            if (document.getElementById('birth_date') != null) {
                var first_name = randomString(5, 'abcdefghijklmnopqrstuvwxyz');
                var last_name = randomString(5, 'abcdefghijklmnopqrstuvwxyz');
                document.getElementById('birth_date').value = '07/18/2001';
                document.getElementById('first_name').value = first_name;
                document.getElementById('last_name').value = last_name;
                document.getElementById('search').click();
            }
        }
        if (pagetitle[j].innerHTML == "Student Account") {
            document.getElementById('create_account').click();
        }
        if (pagetitle[j].innerHTML == "Setup Student Account") {
            var rString = randomString(6, '123456789');
            document.getElementById('ssn').value = "448" + rString;
            document.getElementById('email').value = "wpy22334466@outlook.com";
            document.getElementById('confirm_email').value = "wpy22334466@outlook.com";
            document.getElementById('phone').value = "5804466732";
            document.getElementById('address_1').value = "252 Cody Ridge Road";
            document.getElementById('city').value = "Breckinridge";
            document.getElementById('zip').value = "73721";
            //document.getElementById('Continue').click();
            document.getElementById('state').value = "OK";
            document.getElementById('gender').value = "M";
            document.getElementById('ethnicity').value = "I";
            document.getElementById('residency').value = "F";
            document.getElementById('highest_ed').value = "01";
            document.getElementById('highest_grade').value = "00";
            //document.getElementById('continue').click(); //不能自动，太快An error has occurred.
            setTimeout(function() {
                document.getElementById('continue').click()
            },
            5000);
        }
    }

    //随机字符串
    function randomString(length, chars) {
        var result = '';
        for (var i = length; i > 0; --i) result += chars[Math.floor(Math.random() * chars.length)];
        return result;
    }
    //var rString = randomString(32, '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ');
})();