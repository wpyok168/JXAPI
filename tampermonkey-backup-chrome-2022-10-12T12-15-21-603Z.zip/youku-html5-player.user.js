// ==UserScript==
// @name         youku-html5-player
// @namespace    http://zythum.sinaapp.com/youkuhtml5playerbookmark/
// @version      2.0 beta
// @description  The Programme of Mother Don't Worry About My Macbook Burning Any More v2.0 Beta
// @include      http://*.youku.com/*
// @include      http://v.youku.com/*
// @include      http://*.tudou.com/*
// @include      http://tv.sohu.com/*
// @include      http://*.iqiyi.com/*
// @include      http://*.letv.com/*
// @include      http://video.sina.com.cn/*
// @include      http://v.qq.com/*
// @include      http://61.147.76.6/*
// @include      http://222.141.53.5/*
// @include      http://*.56.com/*
// @include      http://*.bilibili.com/*
// @include      http://*.acfun.tv/*
// @exclude      http://www.acfun.tv/
// @exclude      http://*.weibo.com/*
// @exclude      http://*.sinaimg.cn/*
// @exclude      http://*.yinyuetai.com/*
// @copyright  2012-2013, zythum <zythum02@gmail.com> (http://atalasii.com/)
// ==/UserScript==

(function(){var l = document.createElement('link');l.setAttribute('rel','stylesheet');l.setAttribute('media','all');l.setAttribute('href','http://zythum.sinaapp.com/youkuhtml5playerbookmark/youkuhtml5playerbookmark2.css');document.body.appendChild(l);var s = document.createElement('script');s.setAttribute('src','http://zythum.sinaapp.com/youkuhtml5playerbookmark/youkuhtml5playerbookmark2.js');document.body.appendChild(s);})();