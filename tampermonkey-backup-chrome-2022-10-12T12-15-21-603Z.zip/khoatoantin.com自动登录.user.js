// ==UserScript==
// @name         khoatoantin.com自动登录
// @namespace    http://khoatoantin.com
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        *://khoatoantin.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
document.getElementById('txt-email_user').value='trogiup24h';
document.getElementById('txt-password_user').value='PHO';

setInterval(function a(){
    document.getElementById("btn-login_account").click();
},30);

    // Your code here...


})();