// ==UserScript==
// @name         获取剪贴板内容
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        *://www.baidu.com/*
// @grant        none
// ==/UserScript==
(function() {
    'use strict';
    var obj = document.getElementById("su");
    var copytext = obj.value.toString();
    //alert(copytext.toString());
    navigator.clipboard.writeText(copytext.toString()).then(function() {
        /* clipboard successfully set */
        alert("复制成功！");
    },
    function() {
        /* clipboard write failed */
        var txt ="如你使用的是Firfox浏览器，请打开about:config并将dom.events.testing.asyncClipboard设为true后重试";
        alert("复制失败！\n\n" + txt);
    });
    // Your code here...
})();