// ==UserScript==
// @name         中财远程教育自动播放
// @namespace    http://www.zcycjy.com/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        *://www.zcycjy.com/doCourseStudy?*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
autoplay();
function autoplay() {
    var interval1 = setInterval(function () {
            var btn = document.getElementsByTagName("a");
            for (var i = 0; i < btn.length; i++) {
                if (btn[i].getAttribute("class") == "layui-layer-btn0") {
                    //setTimeout(1000);
                    if (btn[i].outerHtml = "继续播放") {
                        btn[i].click();
                       // var video = document.getElementById("video");
                        //alert(video.innerHtml);
                       // video.click();
                    }
                }
            }
        },
        4000);
};
    // Your code here...
})();