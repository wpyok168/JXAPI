// ==UserScript==
// @name         my.madisoncollege.edu密码
// @namespace    https://my.madisoncollege.edu/app/profile/search
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://my.madisoncollege.edu/app/profile/createaccount
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    var pwd = document.getElementById('password');
    if(pwd!=null){

        document.getElementById('password').value="Edu457667234*";
        document.getElementById('password_confirm').value="Edu457667234*";
        document.getElementById('password_confirm').value="Edu457667234*";
        document.getElementById('recover_answer').value="Edu";
        document.getElementById('recover_question').value="2";
        document.getElementById('agree').click();
        document.getElementById('submit').click();
        //===
    }


})();