// ==UserScript==
// @name         自动登录微软
// @namespace    https://setup.office.com/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        *://setup.office.com/*
// @match        *://login.live.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
var acount = "wpyok500@gmail.com";
var pwd = "Wpy19810603";
var btnSignin = document.getElementById("btnSignin");
if (btnSignin != null) {
    btnSignin.click();
}

geti0116();
function geti0116() {
    var interval1 = setInterval(function() {
        var i0116 = document.getElementById("i0116");
        var databind = i0116.getAttribute("data-bind");
        if (databind.indexOf("ariaDescribedBy") != -1) {
            clearInterval(interval1);
            i0116.value = acount;
            i0116.blur();
            var idSIButton9 = document.getElementById("idSIButton9");
            idSIButton9.click();
        }
    },
    800);
};

geti0118();
function geti0118() {
    var interval1 = setInterval(function() {
        var i0118 = document.getElementById("i0118");
        var databind = i0118.getAttribute("data-bind");
        if (databind.indexOf("ariaDescribedBy") != -1) {
            clearInterval(interval1);
            i0118.value = pwd;
            i0118.blur();
            var idSIButton9 = document.getElementById("idSIButton9");
            idSIButton9.click();
        }
    },
    800);
};
    // Your code here...
})();