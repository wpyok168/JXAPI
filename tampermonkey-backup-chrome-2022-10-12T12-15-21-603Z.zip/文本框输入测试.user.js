// ==UserScript==
// @name         文本框输入测试
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        *://setup.office.com/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    //隐藏部分页面内容
var el = document.getElementsByTagName("div");
for(var i=0;i<el.length;i++)
{
if(el[i].innerHTML.indexOf("PinText")!=-1){}
else if(el[i].innerHTML.indexOf('name="btnNext"')!=-1){}
else if(el[i].innerHTML.indexOf('Microsoft-logo_rgb_c-gray_326x72.png')!=-1){}
else(el[i].innerText="")
}

    //文本框输入
    var PinText1 = document.querySelector("#PinText1");
    var PinText2 = document.querySelector("#PinText2");
    var PinText3 = document.querySelector("#PinText3");
    var PinText4 = document.querySelector("#PinText4");
    var PinText5 = document.querySelector("#PinText5");
    //PinText1.value="DCVKB";
    //PinText2.value="6ND2Y";
    //PinText3.value="QFRT3";
    //PinText4.value="93CTQ";
    //PinText5.value="BHB86";
    inputmsg(PinText1, "DCVKB");
    inputmsg(PinText2, "6ND2Y");
    inputmsg(PinText3, "QFRT3");
    inputmsg(PinText4, "93CTQ");
    inputmsg(PinText5, "BHB86");

    function inputmsg(element, txt){
        var ev = new Event("input",{bubbles:true,cancelable:false});
        element.value=txt;
        element.dispatchEvent(ev);
    };
    // Your code here...
})();