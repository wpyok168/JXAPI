// ==UserScript==
// @name         philka.ru辅助点击
// @namespace    https://philka.ru/forum/
// @version      0.1
// @description  try to take over the world!
// @author       福建-兮
// @match        *://philka.ru/forum/topic/*
// @match        *://philka.ru/forum/user/*
// @grant        none
// ==/UserScript==
// ==UserScript==


(function() {
    'use strict';
    //alert("b");
var btn = document.getElementsByTagName("input");
for (var i = 0; i < btn.length; i++) {
	if (btn[i].getAttribute("value")=="Показать"){
        //setTimeout(1000);
		btn[i].click();
	}
}
    // Your code here...
})();