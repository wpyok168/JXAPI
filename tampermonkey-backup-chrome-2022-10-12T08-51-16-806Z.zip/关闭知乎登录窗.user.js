// ==UserScript==
// @name         关闭知乎登录窗
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        *://zhuanlan.zhihu.com/*
// @include      *://www.zhihu.com/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
var t=setInterval(()=>{
    let closebutton = document.querySelector(".Button.Modal-closeButton.Button--plain");
    if(closebutton!=null){
        clearInterval(t);
        closebutton.click();
    }
},1000);
    // Your code here...
})();