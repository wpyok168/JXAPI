// ==UserScript==
// @name         jac
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://srm.jac.com.cn/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=jac.com.cn
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    var t =setInterval(()=>{
    //var jx = document.querySelector("#vue-admin-beautiful > div > div.layout-container-vertical.fixed > div > div.el-scrollbar.side-bar-container > div.el-scrollbar__wrap > div > ul > div > li > ul > div:nth-child(2) > a > li");
    var jx=document.querySelectorAll(".nest-menu")[7];
        if(jx!=null){

    clearInterval(t);
        jx.remove();
    }
    },100);
    // Your code here...
})();