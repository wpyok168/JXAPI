// ==UserScript==
// @name         获取确认ID
// @namespace    https://microsoft.gointeract.io/interact/index?interaction=1461173234028-3884f8602eccbe259104553afa8415434b4581-05d1&accountId=microsoft&appkey=196de13c-e946-4531-98f6-2719ec8405ce&token=ugyRTu
// @version      0.3
// @description  try to take over the world!
// @author       福建-兮
// @match        *://microsoft.gointeract.io/interact/*
// @match        *://msdev.gointeract.io/interact/*
// @match        *://interact-utm.cloudapp.net/*
// @grant        none
// ==/UserScript==
(function() {
    'use strict';

    //隐藏页面部分内容
function hideElement(){
    var el = document.getElementsByTagName("li");
    for(var i=0;i<el.length;i++)
    {
        if(el[i].innerHTML.indexOf("1461173234025-3129f8602eccbe259104553afa8415434b4581-02de_1461173234023-2569f8602eccbe259104553afa8415434b458-10ae")!=-1){}
        else if(el[i].innerHTML.indexOf("1461173234025-3129f8602eccbe259104553afa8415434b4581-02de_1461173234023-2568f8602eccbe259104553afa8415434b458-10ad")!=-1){}
        else(el[i].innerText="")
    }
    var elp = document.getElementsByTagName("p");
    for(var j=0;j<elp.length;j++)
    {
        if(elp[j].innerHTML.indexOf("Welcome to Microsoft Product Activation")!=-1){elp[j].innerText=""}
    }
}
//奥妙全自动
    function autoCID(){
        //隐藏
        var el = document.getElementsByTagName("li");
        for(var i=0;i<el.length;i++)
        {
            //if(el[i].innerHTML.indexOf("1461173234025-3129f8602eccbe259104553afa8415434b4581-02de_1461173234023-2576f8602eccbe259104553afa8415434b458-10b5")!=-1){}
            //else(el[i].style = "display:none")
            el[i].style = "display:none"
        }

        var elp = document.getElementsByTagName("p");
        for(var j=0;j<elp.length;j++)
        {
            if(elp[j].innerHTML.indexOf("Welcome to Microsoft Product Activation")!=-1){elp[j].innerText=""}
        }
        //添加element
        var popContent ='<li class="jma-click-to-continue-item ui-last-child" aria-disabled="false"><a class="jma-click-to-continue-button ui-btn ui-btn-icon-right ui-icon-carat-r" id="aotoGetCID" a_id="aotoGetCID" role="link" aria-label="aotoGetCID link" aria-level="0" tabindex="0">奥妙全自动</a></li>';
        $('body > div.ui-page.ui-page-theme-a.ui-page-header-fixed.ui-page-footer-fixed.ui-page-active > div.ui-content > div > div.jma-content-section.jma-has-header.jma-has-choices.jma-has-footer > ul').append(popContent);

        var btn6=document.getElementById("1461173234025-3129f8602eccbe259104553afa8415434b4581-02de_1461173234023-2569f8602eccbe259104553afa8415434b458-10ae");
        var btn7=document.getElementById("1461173234025-3129f8602eccbe259104553afa8415434b4581-02de_1461173234023-2568f8602eccbe259104553afa8415434b458-10ad");

        //为添加的element添加点击事件
        document.getElementById("aotoGetCID").onclick=function(){btn6.click()};
}

    //自动获取确认ID
    var resultiid;
    var Digits;
    zero();
    function zero() {
        var interval1 = setInterval(function() {
            Digits = document.getElementById("1461173234025-3129f8602eccbe259104553afa8415434b4581-02de_1461173234023-2568f8602eccbe259104553afa8415434b458-10ad");
            if (Digits != null) {
                clearInterval(interval1);
               // hideElement(); //隐藏页面部分内容
                var iid = prompt("请输入安装ID(注意安装ID位数，否则无法正常获取)：", "安装ID");
                if (iid == "安装ID") {
                    first();
                    return
                } else if (iid == null) {
                    return
                }
                regiid(iid);
                //alert(resultiid);
                if (resultiid != undefined) {
                    first();;
                } else {
                    zero();
                    return
                }
            }
        },
        800);
    }
    //
    function first() {
        var interval = setInterval(function() {
            var iid1 = document.getElementById("field1");
            //alert(iid1);
            if (iid1 != null) {
                clearInterval(interval);
                if (resultiid != null) {
                    setiid();
                } else {
                    first();
                    return
                }
                return;
            }
        },
        800);
    }
    function regiid(iidstr) {
        for (var i = 0; i < iidstr.length; i++) {
            iidstr = iidstr.replace(/[^\u4E00-\u9FA5A-Za-z0-9]/, "");
        }
        var patt1 = /[0-9]{63}/g;
        var patt2 = /[0-9]{54}/g;
        var resultiid1 = iidstr.match(patt1);
        var resultiid2 = iidstr.match(patt2);
        if (resultiid1 != null) {
            resultiid = resultiid1[0].match(/[0-9]{7}/g);
            document.getElementById("1461173234025-3129f8602eccbe259104553afa8415434b4581-02de_1461173234023-2568f8602eccbe259104553afa8415434b458-10ad").click();
        } else if (resultiid2 != null) {
            resultiid = resultiid2[0].match(/[0-9]{6}/g);
            document.getElementById("1461173234025-3129f8602eccbe259104553afa8415434b4581-02de_1461173234023-2569f8602eccbe259104553afa8415434b458-10ae").click();
        } else {
            first();
        }
    }

    function setiid() {
        //document.getElementById("field1").setAttribute("disabled", "");
        //document.getElementById("field2").setAttribute("disabled", "");
        //document.getElementById("field3").setAttribute("disabled", "");
        //document.getElementById("field4").setAttribute("disabled", "");
        //document.getElementById("field5").setAttribute("disabled", "");
        //document.getElementById("field6").setAttribute("disabled", "");
        //document.getElementById("field7").setAttribute("disabled", "");
        //document.getElementById("field8").setAttribute("disabled", "");
        //document.getElementById("field9").setAttribute("disabled", "");
        document.getElementById("field1").removeAttribute("disabled");
        document.getElementById("field2").removeAttribute("disabled");
        document.getElementById("field3").removeAttribute("disabled");
        document.getElementById("field4").removeAttribute("disabled");
        document.getElementById("field5").removeAttribute("disabled");
        document.getElementById("field6").removeAttribute("disabled");
        document.getElementById("field7").removeAttribute("disabled");
        document.getElementById("field8").removeAttribute("disabled");
        document.getElementById("field9").removeAttribute("disabled");
        document.getElementById("field1").value = resultiid[0];
        document.getElementById("field2").value = resultiid[1];
        document.getElementById("field3").value = resultiid[2];
        document.getElementById("field4").value = resultiid[3];
        document.getElementById("field5").value = resultiid[4];
        document.getElementById("field6").value = resultiid[5];
        document.getElementById("field7").value = resultiid[6];
        document.getElementById("field8").value = resultiid[7];
        document.getElementById("field9").value = resultiid[8];
        document.getElementById("1461173234025-3148f8602eccbe259104553afa8415434b4581-02f1").value = resultiid[0];
        document.getElementById("1461173234025-3156f8602eccbe259104553afa8415434b4581-02f9").value = resultiid[1];
        document.getElementById("1461173234025-3153f8602eccbe259104553afa8415434b4581-02f6").value = resultiid[2];
        document.getElementById("1461173234025-3150f8602eccbe259104553afa8415434b4581-02f3").value = resultiid[3];
        document.getElementById("1461173234025-3158f8602eccbe259104553afa8415434b4581-02fb").value = resultiid[4];
        document.getElementById("1461173234025-3157f8602eccbe259104553afa8415434b4581-02fa").value = resultiid[5];
        document.getElementById("1461173234025-3155f8602eccbe259104553afa8415434b4581-02f8").value = resultiid[6];
        document.getElementById("1461173234025-3152f8602eccbe259104553afa8415434b4581-02f5").value = resultiid[7];
        document.getElementById("1461173234025-3151f8602eccbe259104553afa8415434b4581-02f4").value = resultiid[8];
        document.getElementById("custom-msft-submit").setAttribute('class', 'jma-click-to-continue-button ui-btn ui-btn-icon-right ui-icon-carat-r ui-last-child');
        document.getElementById("custom-msft-submit").click();
        setnum();
        getCID();
    }

    function setnum() {
        var interval2 = setInterval(function() {
            var iidnum = document.getElementById("numberOfInstalls");
            if (iidnum != null) {
                clearInterval(interval2);
                document.getElementById("numberOfInstalls").value = 0;
                document.getElementById("1461173234025-3162f8602eccbe259104553afa8415434b4581-02ff").value = 0;
                document.getElementById("custom-msft-submit").setAttribute('class', 'jma-click-to-continue-button ui-btn ui-btn-icon-right ui-icon-carat-r');
                document.getElementById("custom-msft-submit").click();
            }
            var stopgetcid = document.getElementById("1461173234025-3133f8602eccbe259104553afa8415434b4581-02e2_1461173234023-2574f8602eccbe259104553afa8415434b458-10b3");
            if (stopgetcid != null) {
                clearInterval(interval2);
            }
        },
        800);
    }
    function getCID() {
        var interval3 = setInterval(function() {
            var cidtb = document.getElementById("confirmTable");
            if (cidtb != null) {
                //clearInterval(interval3);
                var cid = cidtb.innerHTML.match(/[0-9]{6}/g);
                if (cid[0] != null) {
                    clearInterval(interval3);
                    //alert(cid);
                    //getcid(cid[0]);
                    var copytext = "CID："+cid[0]+cid[1]+cid[2]+cid[3]+cid[4]+cid[5]+cid[6]+cid[7];
                    //alert(copytext.toString());
                    navigator.clipboard.writeText(copytext.toString()).then(function() {
                        /* clipboard successfully set */
                        alert("CID已复制到剪切板！\n"+cid);
                    },
                    function() {
                        /* clipboard write failed */
                        var txt ="如你使用的是Firfox浏览器，请打开about:config并将dom.events.testing.asyncClipboard设为true后重试";
                        alert("复制失败！\n\n" + txt);
                    });
                }
            }
        },
        800);
    }

    // Your code here...
})();