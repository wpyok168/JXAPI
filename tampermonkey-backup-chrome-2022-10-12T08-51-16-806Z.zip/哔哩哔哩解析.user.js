// ==UserScript==
// @name         哔哩哔哩解析
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        *://www.bilibili.com/bangumi/play/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    //解析接口===
    //https://jx.renrenmi.cc/?url=
    //https://123.1dior.cn/?url=
    //https://jiexi.t7g.cn/?url=
    //https://dm.2g88.vip/?url=
    //https://jx.parwix.com:4433/player/?url=
    //https://17kyun.com/api.php?url=
    var videoapi="https://17kyun.com/api.php?url=";
    //======

    var api;var videourl;
    function getapi(){
        videourl=window.location.href;
        if(videourl.indexOf('?')!=-1){
            videourl=videourl.slice(0,videourl.indexOf('?'));
        }
        api=videoapi+videourl;
    }
    getapi();

    function novip(){
var tt = setInterval(function(){
    if(document.querySelector(".bpx-player-video-wrap")!=null){
    document.querySelector(".bpx-player-video-wrap").outerHTML="";

    var div = document.createElement("div");
    div.setAttribute("class","bpx-player-video-wrap");
    div.innerHTML='<iframe id="videoiframe" src="'+ api +'" allow="autoplay; fullscreen; payment" autoplay="autoplay" autoload="true" allow="autoplay; fullscreen; payment" style="position: absolute; width: 98%; height: 100%; top:0px; border: none; "></iframe>';
    div.children.videoiframe.onload=function(){qhvideo();};
    document.querySelector(".bpx-player-video-perch").appendChild(div);
    document.querySelector(".squirtle-controller.squirtle-pgc").outerHTML="";
        if(document.querySelector(".leleplayer-setting > button.leleplayer-icon.leleplayer-setting-speeds")!=null){
            document.querySelector(".leleplayer-setting > button.leleplayer-icon.leleplayer-setting-speeds").outerHTML="";
            document.querySelector(".bpx-player-dm-wrap").outerHTML="";
        }

        clearInterval(tt);
    }

},500);
        }

var vip = setInterval(function(){
    if(document.querySelector(".mask-container")!=null){
    document.querySelector(".player-limit-mask.pay").outerHTML="";
    var div = document.createElement("div");
    div.setAttribute("class","player-limit-mask pay");
    div.innerHTML='<iframe id="videoiframe" src="'+ api +'" width="100%" height="100%" loading="lazy" scrolling="no" sandbox="allow-top-navigation allow-same-origin allow-forms allow-scripts" autoplay="autoplay" autoload="true" allow="autoplay; fullscreen; payment" style="position: absolute; width: 100%; max-width: 100%; height: 100%; max-height: 100%; border: none; outline: none; margin: 0px; padding: 0px;"></iframe>';
    div.children.videoiframe.onload=function(){qhvideo();};
    document.querySelector("#player_mask_module").appendChild(div);
        clearInterval(vip);
    }

},500);

function qhvideo() {
        setInterval(() => {
            getapi();
            if(document.querySelector("#videoiframe").src.indexOf(videourl)==-1){
                if(document.querySelector("#player_mask_module")!=null){
                    document.querySelector("#videoiframe").setAttribute("src",api);
                }
            }//else{novip();}
        },500);
    }

    //novip();
    vip();
    qhvideo();
    // Your code here...
})();