// ==UserScript==
// @name         通用20站全网图库素材VIP高速下载，支持千图网VIP/千库网VIP/包图网VIP/摄图网VIP/昵图网VIP/90设计VIP/觅元素VIP/我图网VIP/17素材VIP/稻壳儿VIP/图品汇VIP等
// @namespace    
// @version      1.2.5.1
// @description  This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @author       
// @grant        GM_getResourceURL
// @match        *://*.51yuansu.com/*
// @match        *://*.ooopic.com/*
// @match        *://*.58pic.com/*
// @match        *://*.nipic.com/*
// @match        *://*.90sheji.com/*
// @match        *://*.588ku.com/*
// @match        *://*.ibaotu.com/*
// @match        *://*.699pic.com/*
// @match        *://download.csdn.net/*
// @match        *://*.docer.com/*
// @match        *://*.17sucai.com/*
// @match        *://*.tukuppt.com/*
// @match        *://*.92sucai.com/*
// @match        *://*.yanj.cn/*
// @match        *://*.netbian.com/*
// @match        *://*.huiyi8.com/*
// @match        *://*.88tph.com/*
// @match        *://*.51miz.com/*
// @match        *://*.16pic.com/*
// @match        *://*.125pic.com/*
// ==/UserScript==
