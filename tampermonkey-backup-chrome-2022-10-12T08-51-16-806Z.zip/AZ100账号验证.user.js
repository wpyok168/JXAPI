// ==UserScript==
// @name         AZ100账号验证
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        *://signup.azure.com/studentverification?offerType=3&*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

var acount = "chanemi@averycoonley.org";

geti0116("#school-email-input");
geti0116("#confirm-school-email-input");
sumitform("#student-verification-submit-button");

sumitform("#accept-terms");
sumitform("#signup-button");

function sumitform(t) {
    var interval1 = setInterval(function() {
        var sum = document.querySelector(t);
        if(sum!=null)
        {
            sum.click();
            clearInterval(interval1);
        }
    },
    2000);
};


function geti0116(t) {
    var interval1 = setInterval(function() {
        var i0116 = document.querySelector(t);
        if (i0116.value=="") {
            keyinput2(i0116,acount)
        }
        if(i0116.value!=""){clearInterval(interval1);}
    },
    800);
};

//模拟键盘输入并触发事件 方法1
function keyinput1(t,value)
{
//let t=document.getElementById("school-email-input");
let evt = document.createEvent('HTMLEvents');
evt.initEvent('input', true, true);
t.value=value;
t.dispatchEvent(evt)
}
//模拟键盘输入并触发事件 方法2
function keyinput2(element,value)
{
var ev = new Event('input', { bubbles: true});
ev.simulated = true;
//let element=document.getElementById("school-email-input")
element.value = value;
element.dispatchEvent(ev);
}
    // Your code here...
})();