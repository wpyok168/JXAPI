// ==UserScript==
// @name         爱奇艺解析
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        *://www.iqiyi.com/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    //解析接口===
    //https://jx.renrenmi.cc/?url=
    //https://123.1dior.cn/?url=
    //https://jiexi.t7g.cn/?url=
    //https://dm.2g88.vip/?url=
    //https://jx.parwix.com:4433/player/?url=
    //"https://17kyun.com/api.php?url=
    //http://www.ikukk.com/?ac=0&url=
    //https://parse.xymov.net/index.php?url=
    var videoapi="https://17kyun.com/api.php?url=";
    //======
    var api;var videourl;
    function getapi(){
        videourl=window.location.href;
        if(videourl.indexOf('?')!=-1){
            videourl=videourl.slice(0,videourl.indexOf('?'));
        }
        api=videoapi+videourl;
    }
    getapi();

       var qhvideo = setInterval(function(){
            getapi();
          if(document.querySelector("#videoiframe")!=null){

            if(document.querySelector("#videoiframe").src.indexOf(videourl)==-1){
                //debugger;
                setTimeout(()=>{
                if(document.querySelector(".select-item.selected>div>img")!=null){
                    document.querySelector("#videoiframe").setAttribute("src",api);
                }
                else
                {
                    window.location.reload();
                }
                },1000);
            }}
if(document.querySelector(".qy-player-vippay-layer")!=null){document.querySelector(".qy-player-vippay-layer").outerHTML="";document.querySelector("#playerPopup").outerHTML="";}
            },500);

var tt=setInterval(function(){
   // debugger;
    var vipfalg = document.querySelector(".select-item.selected>div>img") || document.querySelector('[data-player-hook="videotips"]');
    if(vipfalg!=null){
        clearInterval(tt);
    document.querySelector('[data-player-hook="mainlayer"]').outerHTML="";
    var div = document.createElement("div");
    div.setAttribute("x-webkit-airplay","allow");
    div.style="cursor: default;width:100% height:100%";
    div.setAttribute("_idm_id__","83173377");
    div.allow="autoplay; fullscreen; payment";
    div.innerHTML='<iframe id="videoiframe" src="'+ api +'" allow="autoplay; fullscreen; payment" autoplay="autoplay" autoload="true" allow="autoplay; fullscreen; payment" style="position: absolute; width: 100%; height: 100%; top:-5px; border: none; "></iframe>';
    document.querySelector(".iqp-player").appendChild(div);
    }

},500);


qhvideo();
    tt();

    // Your code here...
})();